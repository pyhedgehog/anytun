<?php
defined( '_VALID_MOS' ) or die( 'Restricted access' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php $iso = split( '=', _ISO );
echo '<?xml version="1.0" encoding="'. $iso[1] .'"?' .'>';
?>
<html>
<head>
<?php mosShowHead(); ?>
<?php
if ( $my->id ) {
	initEditor();
}
?>
<meta http-equiv="Content-Type" content="text/html; <?php echo _ISO; ?>" />
<link href="<?php echo $mosConfig_live_site;?>/templates/red_evolution_citrus_ice/css/template_css.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" language="javascript" src="<?php echo $mosConfig_live_site;?>/templates/<?php echo $mainframe->getTemplate(); ?>/md_stylechanger.js"></script>
</head>

<body>
<div align="center">
<div id="wrapper">

	<div id="header">
                <?php mosLoadModules ( 'header', -1 ); ?>
		<div id="topmenu"><?php mosLoadModules ( 'top_menu', -1 ); ?></div>
	</div><!-- end of header -->

	<div id="container">
		<div id="left_outer">
			<div id="left_top"><div id="left_tl"></div></div>
			<div id="left_inner">
		
				<div id="mainmenu"><?php mosLoadModules ( 'main_menu', -2); ?></div>
				<div id="green_outer">
					<div id="green_top"></div>
					<div id="green_inner"><?php mosLoadModules ( 'green', -2); ?></div>
					<div id="green_bottom"></div>
				</div> <!-- end of green_outer -->
		
				<div id="left"><?php mosLoadModules ( 'left', -2 ); ?></div>
		
			
			</div><!-- end of left_inner -->
<div id="left_bottom"><div id="left_br"></div></div>
		</div><!-- end of left_outer -->

		<div id="mainarea">
			<div id="mainbody_outer">
				<div id="mainbody_top"><div class="tl"></div></div>
				<div id="mainbody_inner">	
						<div id="pathway_text"><?php mosPathWay(); ?></div>
						
					<div id="main_content"><?php mosMainBody(); ?></div>
                               
                                </div><!--end of mainbody_inner -->

 <div id="mainbody_bottom"><div class="br"></div></div>
			</div><!-- end of mainbody_outer -->
			<?php if(mosCountModules('user1')){ ?>
			<div id="mainarea_center"><?php mosLoadModules ( 'user1', -2 ); ?></div>
                        <?php } ?>
			<div id="user2_outer">
				<div id="user2_top"><div class="tl"></div></div>
				<div id="user2_inner"><?php mosLoadModules ( 'user2', -2 ); ?></div>
				<div id="user2_bottom"><div class="br"></div></div>
			</div>
		</div><!-- end of mainarea -->

	</div><!-- end of container -->
<div class="clr"></div>
<div id="footer"><?php mosLoadModules ( 'footer', -1 ); ?> <br/> Designed by <a href="http://www.redevolution.com" target="_blank">Red Evolution</a></div>

</div> <!-- end of wrapper -->

</div> <!-- end of center div -->
 
</body>
</html>